package ru.vsu.cs.kg24.Sgibanov_M_V;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class SectorFilling extends Application {

    private static final int WIDTH = 800;
    private static final int HEIGHT = 800;

    private TextField centerXField;
    private TextField centerYField;
    private TextField radiusField;
    private TextField startAngleField;
    private TextField endAngleField;
    private ColorPicker startColorPicker;
    private ColorPicker endColorPicker;

    @Override
    public void start(Stage primaryStage) {
        GridPane inputPane = new GridPane();
        inputPane.setPadding(new Insets(10));
        inputPane.setHgap(10);
        inputPane.setVgap(10);

        centerXField = new TextField("400");
        centerYField = new TextField("400");
        radiusField = new TextField("300");
        startAngleField = new TextField("45");
        endAngleField = new TextField("135");
        startColorPicker = new ColorPicker(Color.RED);
        endColorPicker = new ColorPicker(Color.BLUE);

        inputPane.add(new Label("Центр X:"), 0, 0);
        inputPane.add(centerXField, 1, 0);
        inputPane.add(new Label("Центр Y:"), 0, 1);
        inputPane.add(centerYField, 1, 1);
        inputPane.add(new Label("Радиус:"), 0, 2);
        inputPane.add(radiusField, 1, 2);
        inputPane.add(new Label("Стартовый угол:"), 0, 3);
        inputPane.add(startAngleField, 1, 3);
        inputPane.add(new Label("Конечный угол:"), 0, 4);
        inputPane.add(endAngleField, 1, 4);
        inputPane.add(new Label("Стартовый цвет:"), 0, 5);
        inputPane.add(startColorPicker, 1, 5);
        inputPane.add(new Label("Конечный цвет:"), 0, 6);
        inputPane.add(endColorPicker, 1, 6);

        Button drawButton = new Button("Нарисовать сектор");
        inputPane.add(drawButton, 0, 7, 2, 1);

        Button clearButton = new Button("Очистить");
        inputPane.add(clearButton, 0, 8, 2, 1);

        Pane root = new Pane();
        Canvas canvas = new Canvas(WIDTH, HEIGHT);
        GraphicsContext gc = canvas.getGraphicsContext2D();
        root.getChildren().add(canvas);

        drawButton.setOnAction(e -> {
            int centerX = Integer.parseInt(centerXField.getText());
            int centerY = Integer.parseInt(centerYField.getText());
            int radius = Integer.parseInt(radiusField.getText());
            double startAngle = Double.parseDouble(startAngleField.getText());
            double endAngle = Double.parseDouble(endAngleField.getText());
            Color startColor = startColorPicker.getValue();
            Color endColor = endColorPicker.getValue();

            drawSector(gc, centerX, centerY, radius, startAngle, endAngle, startColor, endColor);
        });

        clearButton.setOnAction(e -> {
            gc.clearRect(0, 0, WIDTH, HEIGHT);
        });

        root.getChildren().add(inputPane);

        primaryStage.setScene(new Scene(root, WIDTH, HEIGHT));
        primaryStage.setTitle("Sector Filling with Color Interpolation");
        primaryStage.show();
    }

    private void drawSector(GraphicsContext gc, int centerX, int centerY, int radius, double startAngle, double endAngle, Color startColor, Color endColor) {
        double startRad = Math.toRadians(startAngle);
        double endRad = Math.toRadians(endAngle);

        List<Point> points = new ArrayList<>();
        points.add(new Point(centerX, centerY));

        int numPoints = 300; // Количество точек для интерполяции
        for (int i = 0; i <= numPoints; i++) {
            double angle = startRad + (endRad - startRad) * i / numPoints;
            int x = (int) (centerX + radius * Math.cos(angle));
            int y = (int) (centerY + radius * Math.sin(angle));
            points.add(new Point(x, y));
        }

        // Рисуем границу сектора с помощью алгоритма Брезенхема
        drawBresenhamLines(gc, centerX, centerY, points);

        // Заполняем сектор
        fillPolygon(gc, points, startColor, endColor, startRad, endRad);
    }

    private void drawBresenhamLines(GraphicsContext gc, int centerX, int centerY, List<Point> points) {
        for (int i = 0; i < points.size() - 1; i++) {
            Point p1 = points.get(i);
            Point p2 = points.get(i + 1);
            drawLineBresenham(gc, p1.x, p1.y, p2.x, p2.y);
        }
    }

    private void drawLineBresenham(GraphicsContext gc, int x0, int y0, int x1, int y1) {
        int deltax = Math.abs(x1 - x0);
        int deltay = Math.abs(y1 - y0);
        int y = y0;
        int diry = (y1 > y0) ? 1 : -1;

        int error = 0;
        int deltaerr = (deltay + 1);

        for (int x = x0; x <= x1; x++) {
            gc.fillRect(x, y, 1, 1); // Рисуем пиксель

            error += deltaerr;
            if (error >= (deltax + 1)) {
                y += diry;
                error -= (deltax + 1);
            }
        }
    }

    private void fillPolygon(GraphicsContext gc, List<Point> points, Color startColor, Color endColor, double startRad, double endRad) {
        int minX = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int minY = Integer.MAX_VALUE;
        int maxY = Integer.MIN_VALUE;

        for (Point point : points) {
            minX = Math.min(minX, point.x);
            maxX = Math.max(maxX, point.x);
            minY = Math.min(minY, point.y);
            maxY = Math.max(maxY, point.y);
        }

        for (int y = minY; y <= maxY; y++) {
            List<Integer> intersections = new ArrayList<>();
            for (int i = 0; i < points.size(); i++) {
                int j = (i + 1) % points.size();
                Point p1 = points.get(i);
                Point p2 = points.get(j);

                if ((p1.y <= y && p2.y > y) || (p2.y <= y && p1.y > y)) {
                    int x = (int) (p1.x + (double) (y - p1.y) / (p2.y - p1.y) * (p2.x - p1.x));
                    intersections.add(x);
                }
            }

            intersections.sort(Integer::compareTo);

            for (int i = 0; i < intersections.size(); i += 2) {
                int x1 = intersections.get(i);
                int x2 = intersections.get(i + 1);
                for (int x = x1; x <= x2; x++) {
                    double angle = Math.atan2(y - HEIGHT / 2, x - WIDTH / 2);
                    if (angle < 0) angle += 2 * Math.PI;

                    if (angle >= startRad && angle <= endRad) {
                        double t = (angle - startRad) / (endRad - startRad);
                        Color color = interpolateColor(startColor, endColor, t);
                        gc.setFill(color);
                        gc.fillRect(x, y, 1, 1);
                    }
                }
            }
        }
    }

    private Color interpolateColor(Color startColor, Color endColor, double t) {
        double r = startColor.getRed() + t * (endColor.getRed() - startColor.getRed());
        double g = startColor.getGreen() + t * (endColor.getGreen() - startColor.getGreen());
        double b = startColor.getBlue() + t * (endColor.getBlue() - startColor.getBlue());
        double a = startColor.getOpacity() + t * (endColor.getOpacity() - startColor.getOpacity());
        return new Color(r, g, b, a);
    }

    private static class Point {
        int x, y;

        Point(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}