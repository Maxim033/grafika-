package ru.vsu.cs.kg24.Sgibanov_M_V;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}